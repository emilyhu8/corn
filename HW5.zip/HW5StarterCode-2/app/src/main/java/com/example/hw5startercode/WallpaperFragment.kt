package com.example.hw5startercode

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import com.bumptech.glide.Glide
import java.io.IOException


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"


/**
 * A simple [Fragment] subclass.
 * Use the [WallpaperFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class WallpaperFragment : Fragment() {
        // TODO: Rename and change types of parameters
        private lateinit var wallpaper: ImageView
        private var position: Int=0
        private var images= arrayOf<Int>(R.raw.wall1, R.raw.wall2,R.raw.wall3, R.raw.wall4, R.raw.wall5, R.raw.wall6 )


        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            arguments?.let{
                position=it.getInt(ARG_PARAM1)
            }

        }

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            // Inflate the layout for this fragment

            val view=inflater.inflate(R.layout.fragment_wallpaper, container, false)
            wallpaper=view.findViewById(R.id.imageView)
            wallpaper.setImageResource(images[position-1])
            /* Code for network call but it doesnt work due to error 503
            getPicture(position-1, requireActivity()){url ->

                Glide.with(requireContext())
                    .load(url)
                    .centerCrop()
                    .into(wallpaper)



            }
            */
            val wallpaperManager=WallpaperManager.getInstance(context)

            val button: Button =view.findViewById(R.id.wallpaperButton)
            button.text="set wallpaper as: " + position.toString()
            button.setOnClickListener{
                wallpaperManager.setResource(images[position-1])
            }


            return view
        }

        companion object {
            @JvmStatic
            fun newInstance(position: Int)
            = WallpaperFragment().apply {
                arguments=Bundle().apply {
                    putInt(ARG_PARAM1, position)
                }
            }
        }
    }

