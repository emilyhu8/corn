package com.example.lec6demo

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Note(
    val title: String? = "",
    val body: String,
    val timestamp: Int = -1,
    val username: String? = "",

)