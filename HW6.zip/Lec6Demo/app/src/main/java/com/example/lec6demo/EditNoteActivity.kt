package com.example.lec6demo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.Request

class EditNoteActivity : AppCompatActivity() {
    private lateinit var editTitle: EditText
    private lateinit var editBody: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note)

        editTitle = findViewById(R.id.editTitle)
        editBody=findViewById(R.id.editBody)
        saveButton = findViewById(R.id.saveLocalButton)

        val body = intent.extras?.getString("body")
        val title=intent.extras?.getString("title")

        editTitle.setText(title!!)
        editBody.setText(body!!)
        saveButton.setOnClickListener {
            val editedNote=Note(editTitle.text.toString(), editBody.text.toString())
            Repository.noteList.add(editedNote)
            val intent=Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}

